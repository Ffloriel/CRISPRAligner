#! /usr/bin/python3
from Bio import Seq, SeqIO
import sys, time, os, re

def findCRR12(query):
	CRR1=list("GTGTTCCCCGCGTGAGCGGGGATAAACCG")
	CRR2=list("GTGTTCCCCGCGTATGCGGGGATAAACCG")
	CRR1match=0
	CRR2match=0
	
	for i in range(len(CRR1)):
		if query[i] == CRR1[i]:
			CRR1match+=1
		if query[i] == CRR2[i]:
			CRR2match+=1

	if (CRR1match >= CRR2match):
		return(CRR1match)
	if (CRR2match >= CRR1match):
		return(0-CRR2match)

def findCRR4(query):
	CRR4=list("GTTCACTGCCGTACAGGCAGCTTAGAAA")
	
	CRR4match=0
	
	for i in range(len(CRR4)):
		if query[i] == CRR4[i]:
			CRR4match+=1

	return(CRR4match)

def recordCount(file):
	seqFile=open(file,"rU")
	seqObj=SeqIO.parse(seqFile,"fasta")
	
	count=0
	
	for record in seqObj:
		count+=1
	seqFile.close()
	return(count)

path = os.getcwd()

totalRecordCount=recordCount(path+"/Results/"+sys.argv[1])

seqFile=open(path+"/Results/"+sys.argv[1],"rU")
wFileAll=open(path+"/Results/AllCRR/"+sys.argv[2]+"AllCRR.fasta","w")
wFileCRR1=open(path+"/Results/CRR1/"+sys.argv[2]+"CRR1.fasta","w")
wFileCRR2=open(path+"/Results/CRR2/"+sys.argv[2]+"CRR2.fasta","w")
wFileCRR4=open(path+"/Results/CRR4/"+sys.argv[2]+"CRR4.fasta","w")
csvFile=open(path+"/Results/"+sys.argv[2]+"Results.csv","w")
errorFile=open(path+"/Results/"+sys.argv[2]+"Error.fasta","w")
seqObj=SeqIO.parse(seqFile,"fasta")

check1=list("GTGTTC")
check2=list("GATAAACC")
check3=list("GTTCAC")
check4=list("GTACGGG")

csvFile.write("Strain ID, CRR1 Spacers, CRR2 Spacers, CRR4 Spacers, Total Spacers\n")

recordCount=0

errorFile.write("Potential assembly errors found in the following spacers:\n\n") 

for record in seqObj:
	recordCount+=1
	print("Starting %s (%i/%i)" % (record.id, recordCount, totalRecordCount))

	CRR1Count=0
	CRR2Count=0
	CRR4Count=0
	
	seq=record.seq	
	if "CGGTTTATCCCCGCTCACGCGGGGAACAC" in seq:
		seq=list(seq.reverse_complement())
	else:
		seq=list(seq)
		
	for m in range (len(seq)-29):
		if seq[m:m+6] == check1 or seq[m+20:m+28] == check2:
			for n in range (100):
		
				if findCRR12(seq[m:m+29]) >= 22 and findCRR12(seq[m+59+n:m+88+n]) >= 22:
					if len("".join(seq[m+29:m+59+n])) > 35:
						errorFile.write(">%s CRR1Spacer%i %i:%i\n" % (record.id,CRR1Count, m+30, m+59+n))
						errorFile.write("".join(seq[m+29:m+59+n])+"\n")
						break
					else:
						CRR1Count+=1
						wFileAll.write(">%s CRR1Spacer%i %i:%i\n" % (record.id,CRR1Count, m+30, m+59+n))
						wFileAll.write("".join(seq[m+29:m+59+n])+"\n")
						wFileCRR1.write(">%s CRR1Spacer%i %i:%i\n" % (record.id,CRR1Count, m+30, m+59+n))
						wFileCRR1.write("".join(seq[m+29:m+59+n])+"\n")			
						break
				
				elif findCRR12(seq[m:m+29]) <= -22 and findCRR12(seq[m+59+n:m+88+n]) <= -22:
					if len("".join(seq[m+29:m+59+n])) > 35:
						errorFile.write(">%s CRR2Spacer%i %i:%i\n" % (record.id,CRR2Count, m+30, m+59+n))
						errorFile.write("".join(seq[m+29:m+59+n])+"\n")
						break
					else:
						CRR2Count+=1
						wFileAll.write(">%s CRR2Spacer%i %i:%i\n" % (record.id,CRR2Count, m+30, m+59+n)) 
						wFileAll.write("".join(seq[m+29:m+59+n])+"\n")
						wFileCRR2.write(">%s CRR2Spacer%i %i:%i\n" % (record.id,CRR2Count, m+30, m+59+n)) 
						wFileCRR2.write("".join(seq[m+29:m+59+n])+"\n")
						break
				
		elif seq[m:m+6] == check3 or seq[m+10:m+17] == check4:
			for n in range (100):
				if findCRR4(seq[m:m+28]) >= 21 and findCRR4(seq[m+58+n:m+86+n]) >= 21:
					if len("".join(seq[m+29:m+59+n])) > 35:
						errorFile.write(">%s CRR1Spacer%i %i:%i\n" % (record.id,CRR4Count, m+30, m+59+n))
						errorFile.write("".join(seq[m+29:m+59+n])+"\n")
						break
					else:
						CRR4Count+=1
						wFileAll.write(">%s CRR4Spacer%i %i:%i\n" % (record.id,CRR4Count, m+29, m+58+n))
						wFileAll.write("".join(seq[m+28:m+58+n])+"\n")
						wFileCRR4.write(">%s CRR4Spacer%i %i:%i\n" % (record.id,CRR4Count, m+29, m+58+n))
						wFileCRR4.write("".join(seq[m+28:m+58+n])+"\n")
						break

		
	wFileAll.write("\n")
	wFileCRR1.write("\n")
	wFileCRR2.write("\n")
	wFileCRR4.write("\n")
	
	print("Spacers Found: CRR1 %i, CRR2 %i, CRR4 %i, total %i" % (CRR1Count,CRR2Count,CRR4Count,CRR1Count+CRR2Count+CRR4Count))
	csvFile.write("%s, %i, %i, %i, %i\n" % (record.id, CRR1Count,CRR2Count,CRR4Count,CRR1Count+CRR2Count+CRR4Count))
	
seqFile.close()
wFileAll.close()
wFileCRR1.close()
wFileCRR2.close()
wFileCRR4.close()
csvFile.close()
