#! /usr/bin/python3

import sys, os
from Bio import SeqIO, Seq


#Load .Fasta as Reference
fileRef=open(sys.argv[1], "r")
sequenceRef=SeqIO.parse(fileRef, "fasta")

path = os.getcwd()
fileOut=open(path+"/Results/"+sys.argv[2]+".fasta", "a+")

for recordRef in sequenceRef:
	fileOut.write(recordRef.format("fasta"))
	
fileRef.close()
fileOut.close()

