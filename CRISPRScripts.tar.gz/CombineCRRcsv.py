#! /usr/bin/python3

import sys, os
from Bio import SeqIO, Seq

path = os.getcwd()
CRR1File=open(path+"/Results/"+sys.argv[1], "r")
CRR2File=open(path+"/Results/"+sys.argv[2], "r")
CRR4File=open(path+"/Results/"+sys.argv[3], "r")
fileOut=open(path+"/Results/"+sys.argv[4], "w")

CRR1Spacers=[]
CRR2Spacers=[]
CRR4Spacers=[]

for line in CRR1File:
	line=line.strip("\n")
	line=line.strip()
	CRR1Spacers.append(line.split(","))
for line in CRR2File:
	line=line.strip("\n")
	line=line.strip()
	CRR2Spacers.append(line.split(","))
for line in CRR4File:
	line=line.strip("\n")
	line=line.strip()
	CRR4Spacers.append(line.split(","))

for m in range(len(CRR1Spacers)):
	for n in range(len(CRR1Spacers[m])):
		fileOut.write("%s," % (CRR1Spacers[m][n]))
	for o in range(1, len(CRR2Spacers[m])):
		fileOut.write("%s," % (CRR2Spacers[m][o]))
	for p in range(1, len(CRR4Spacers[m])):
		fileOut.write("%s," % (CRR4Spacers[m][p]))
	fileOut.write("\n")
		
CRR1File.close()
fileOut.close()

