#! /usr/bin/python3

import sys, os
from Bio import SeqIO, Seq

path = os.getcwd()
CRR1File=open(path+"/Results/"+sys.argv[1], "r")
CRR2File=open(path+"/Results/"+sys.argv[2], "r")
CRR4File=open(path+"/Results/"+sys.argv[3], "r")
fileOut=open(path+"/Results/"+sys.argv[4], "w")

CRR1Spacers=[]
CRR2Spacers=[]
CRR4Spacers=[]


skip=0
for line1 in CRR1File:
	CRR2File=open(path+"/Results/"+sys.argv[2], "r")
	CRR4File=open(path+"/Results/"+sys.argv[3], "r")
	if skip < 1:
		line1=line1.strip("\n")
		line1=line1.split(" ")
		for line2 in CRR2File:
			line2=line2.strip("\n")
			line2=line2.split(" ")
			break
		for line4 in CRR4File:
			line4=line4.strip("\n")
			line4=line4.split(" ")
			break
		morphCount=int(line1[1])+int(line2[1])+int(line4[1])
		fileOut.write("%s %i\n" % (line1[0],morphCount))
		skip+=1
	else:
		line1=line1.strip("\n")
		fileOut.write(line1)
		for line2 in CRR2File:
			line2=line2.strip("\n")
			if line1[:10] == line2[:10]:
				fileOut.write(line2[10:])
		for line4 in CRR4File:
			line4=line4.strip("\n")
			if line1[:10] == line4[:10]:
				fileOut.write(line4[10:])
		fileOut.write("\n")
	CRR2File.close()
	CRR4File.close()
CRR1File.close()
fileOut.close()