#! /usr/bin/python3

import sys, os
from Bio import SeqIO, Seq

path = os.getcwd()
CRR1File=open(path+"/Results/"+sys.argv[1], "r")
CRR1=SeqIO.parse(CRR1File, "fasta")
fileOut=open(path+"/Results/"+sys.argv[4], "w")

for record1 in CRR1:
	fileOut.write(">"+record1.id+"\n"+str(record1.seq))
	CRR2File=open(path+"/Results/"+sys.argv[2], "r")
	CRR2=SeqIO.parse(CRR2File, "fasta")
	for record2 in CRR2:
		if record1.id == record2.id:
			fileOut.write(str(record2.seq))
	CRR2File.close()
	CRR4File=open(path+"/Results/"+sys.argv[3], "r")
	CRR4=SeqIO.parse(CRR4File, "fasta")
	for record4 in CRR4:
		if record1.id == record4.id:
			fileOut.write(str(record4.seq))
	CRR4File.close()
	fileOut.write("\n")
		
CRR1File.close()
fileOut.close()

