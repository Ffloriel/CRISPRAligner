#! /usr/bin/python3
from Bio import SeqIO, Seq
import sys, os, time

# Check for SNPs
def matchCRR(query,reference):
	CRRMatch=0
	CRRRevMatch=0
	reference=list(reference)
	for i in range(len(reference)):
		try:
			if query[i] == reference[i]:
				CRRMatch+=1
		except:
			break
	for i in range(len(reference)):
		try:
			if query[-i-1] == reference[-i-1]:
				CRRRevMatch+=1
		except:
			break
	return([CRRMatch, CRRRevMatch])

# Extract and arrange cassettes
path = os.getcwd()
seqFile=open(path+"/Results/"+sys.argv[1],"rU")
seqObj=SeqIO.parse(seqFile, "fasta")

sampleList=[]
start=True
first=True
sample=[]
isolateNum=0
for record in seqObj:
	if start:
		start = False
		preName=(record.id)
	if preName in record.id:
		sample.append(str(record.seq))
	else:
		if first:
			sample.insert(0, preName)
			sampleList.append(sample)
			first=False
			preName=record.id
			sample=[]
			sample.append(str(record.seq))
		else:
			inserted=False
			sample.insert(0, preName)
			for a in range(len(sampleList)):
				if len(sample) > len(sampleList[a]):
					inserted=True
					sampleList.insert(a, sample)
					break
			if not inserted:
				sampleList.append(sample)
			preName=record.id
			sample=[]
			sample.append(str(record.seq))

sample.insert(0, preName)
inserted=False
for b in range(len(sampleList)):
	if len(sample) > len(sampleList[b]):
		inserted=True
		sampleList.insert(b, sample)
		break
if not inserted:
	sampleList.append(sample)
		
seqFile.close()

# Generate consensus
start=True
first=True
consensus=[]	
upstream=[]

for cassette in sampleList:
	last=False
	if first:
		first=False
		for c in range(1, len(cassette)):
			consensus.append(cassette[c])
	else:
		noCRRMatch=True
		for d in range(1, len(cassette)):
			match=False
			for e in range(len(consensus)):
				consensusMatch=matchCRR(cassette[d], consensus[e])
				if consensusMatch[0]>=(len(consensus[e])-2) or consensusMatch[1]>=(len(consensus[e])-2):
					if len(cassette[d]) > len(consensus[e]):
						consensus[e] = cassette[d]
					noCRRMatch=False
					match=True
					if len(upstream)>=1:
						upstream=upstream[::-1]
						for f in range(len(upstream)):
							consensus.insert(e, upstream[f])
					upstream=[]
					last=False
					break
			if not match:
				upstream.append(cassette[d])
				last=True
		if noCRRMatch:
			for g in range(len(upstream)):
				consensus.append(upstream[g])
			upstream=[]
	if last:
		try:
			for g in range(len(upstream)):
				consensus.append(upstream[g])
			upstream=[]
		except:
			continue
	
consensus.insert(0, "Consensus")

# Write consensus 
csvFile=open(path+"/Results/"+sys.argv[2], "w")
alignFile=open(path+"/Results/"+sys.argv[3], "w")
uniqueFile=open(path+"/Results/"+sys.argv[4], "w")
binaryFile=open(path+"/Results/"+sys.argv[5], "w")

csvFile.write("%s," % (consensus[0]))
for h in range(1, len(consensus)):
	csvFile.write("%s," % (consensus[h]))
	uniqueFile.write(">Consensus%i\n%s\n" % (h, consensus[h]))
csvFile.write("\n")

alignFile.write(">Consensus\n%s\n" % ("".join(consensus[1:])))

binaryFile.write("%i %i\n" % (len(sampleList), len(consensus)-1))

# Align and write cassettes
for i in range(len(sampleList)):
	csvFile.write("%s," % (sampleList[i][0]))
	alignFile.write(">%s\n" % (sampleList[i][0]))
	binaryCount=0
	for p in range(3, len(sampleList[i][0])):
		if binaryCount == 10:
			break
		binaryFile.write("%s" % (sampleList[i][0][p]))
		binaryCount+=1
	if len(sampleList[i][0]) < 13:
		for q in range(13-len(sampleList[i][0])):
			binaryFile.write(" ")
	for k in range(1, len(consensus)):
		hsp=False
		for j in range(1, len(sampleList[i])):	
			consensusMatch=matchCRR(sampleList[i][j], consensus[k])
			if consensusMatch[0]>=len(consensus[k])-2 or consensusMatch[1]>=len(consensus[k])-2:
				hsp=True
				csvFile.write("%sS%i," % (sys.argv[6], j))
				binaryFile.write("1")
				if len(sampleList[i][j]) != len(consensus[k]) and consensusMatch[0] < consensusMatch[1]:
					for n in range(len(consensus[k]) - len(sampleList[i][j])):
						alignFile.write("-")
				alignFile.write("%s" % (sampleList[i][j]))
				if len(sampleList[i][j]) != len(consensus[k]) and consensusMatch[0] > consensusMatch[1]:
					for n in range(len(consensus[k]) - len(sampleList[i][j])):
						alignFile.write("-")
				sampleList[i][j]="Taken"
				break
		if not hsp:
			csvFile.write(",")
			binaryFile.write("0")
			for m in range(len(consensus[k])):
				alignFile.write("-")
	csvFile.write("\n")
	alignFile.write("\n")
	binaryFile.write("\n")
csvFile.close()
alignFile.close()
uniqueFile.close()
binaryFile.close()

